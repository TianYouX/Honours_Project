package com.e_cclesia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.baoyachi.stepview.HorizontalStepView;
import com.baoyachi.stepview.bean.StepBean;

import java.util.ArrayList;
import java.util.List;

public class BallotCastingActivity extends AppCompatActivity {

    private ImageView ivLefticon;
    private TextView tvToolbartitle;
    private ImageButton ibtnElectiondetails_voting;
    private Dialog dDialog;
    private ProgressDialog progressDialog;
    private HorizontalStepView svTimelinevoting;
    private AutoCompleteTextView actSelectcandidate;
    private String candiate_selected;
    private Button btnVote;
    private TextView tvSelecthint;
    private TextView tvAfterselecthint;
    private List<StepBean> sources = new ArrayList<>();

    private TextView tvTitleea;
    private TextView tvTitleelection;
    private String [] candidates;

    //temp
//    private Button btnNext;
    //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ballot_casting);

        tvTitleea = findViewById(R.id.tv_title_ea);
        tvTitleelection = findViewById((R.id.tv_title_election));
        ivLefticon = findViewById(R.id.iv_lefticon);
        tvToolbartitle = findViewById(R.id.tv_toolbartitle);
        ibtnElectiondetails_voting = findViewById(R.id.ibtn_popup_electiondetails_voting);
        svTimelinevoting = findViewById(R.id.sv_timeline_voting);
        actSelectcandidate = findViewById(R.id.act_select_candiate);
        btnVote = findViewById(R.id.btn_vote);
        tvSelecthint = findViewById(R.id.tv_selecthint);
        tvAfterselecthint = findViewById(R.id.tv_afterselecthint);

        Intent intent = getIntent();
        ElectionModel electionModel = intent.getParcelableExtra("ELECTION_MODEL");
        tvTitleea.setText(electionModel.getEaName()+":");
        tvTitleelection.setText(electionModel.getElectionName());
        candidates = electionModel.getCandidates();

        // temp
//        btnNext = findViewById(R.id.btn_next);
//        btnNext.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                Intent intent = new Intent(BallotCastingActivity.this, BallotOpeningActivity.class);
//                intent.putExtra("ELECTION_MODEL",electionModel);
//                startActivity(intent);
//            }
//        });
        //

        // set up the toolbar
        ivLefticon.setImageResource(R.drawable.ic_baseline_arrow_back_24);
        tvToolbartitle.setText("Ballot Casting");
        ivLefticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // the pop-up election details
        dDialog = new Dialog(this);
        ibtnElectiondetails_voting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dDialog.setContentView(R.layout.popup_electiondetails);
                dDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dDialog.show();
            }
        });

        // set up timeline
        setupTimeline(svTimelinevoting);

        // drop-down menu operations
        ArrayAdapter<String> adapterItems = new ArrayAdapter<String>(this, R.layout.list_candidates, candidates);
        actSelectcandidate.setAdapter(adapterItems);
        actSelectcandidate.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                in.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                btnVote.setEnabled(true);
                candiate_selected = parent.getItemAtPosition(position).toString();
            }
        });

        // onClickListener of the VOTE button
        btnVote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(BallotCastingActivity.this);
                builder.setTitle("Ballot Casting");
                builder.setMessage("Do you comfirm that you want to vote for: " + candiate_selected + "?");
                builder.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        progressDialog = new ProgressDialog(BallotCastingActivity.this);
                        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                        progressDialog.setTitle("Voting");
                        progressDialog.setMessage("Verifying if your vote is sent successfully...");
                        progressDialog.setCancelable(false);
                        progressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // when cancel
                            }
                        });

                        progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface dialog) {
                                // when voting success
                                btnVote.setEnabled(false);
                                tvSelecthint.setVisibility(View.INVISIBLE);
                                tvAfterselecthint.setVisibility(View.VISIBLE);
                                actSelectcandidate.setDropDownHeight(0);
                                sources.set(1, new StepBean("Voted",1));
                                svTimelinevoting.setStepViewTexts(sources);
                            }
                        });

                        progressDialog.show();
                        handler.sendEmptyMessage(0);

                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });
    }

    // progressDialog handler
    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if (progressDialog.getProgress() < 100){
                handler.postDelayed(runnable,500);
            }else{
                progressDialog.cancel();
            }
        }
    };

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            progressDialog.setProgress(progressDialog.getProgress()+10);
            handler.sendEmptyMessage(0);
        }
    };

    // set up timeline
    private void setupTimeline(HorizontalStepView sv){
        sources.add(new StepBean("Voting\nPeriod\nStarts",1));
        sources.add(new StepBean("Voted",-1));
        sources.add(new StepBean("Voting\nPeriod\nEnds",-1));
        sources.add(new StepBean("Results",-1));

        sv.setStepViewTexts(sources)
                .setTextSize(12)
                .setStepsViewIndicatorCompletedLineColor(Color.parseColor("#FF9900"))
                .setStepViewComplectedTextColor(Color.parseColor("#FF000000"))
                .setStepsViewIndicatorUnCompletedLineColor(Color.parseColor("#FF000000"))
                .setStepViewUnComplectedTextColor(Color.parseColor("#FF000000"))
                .setStepsViewIndicatorDefaultIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_uncompleted))
                .setStepsViewIndicatorCompleteIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_completed));
        sv.setScrollBarSize(20);
    }

}