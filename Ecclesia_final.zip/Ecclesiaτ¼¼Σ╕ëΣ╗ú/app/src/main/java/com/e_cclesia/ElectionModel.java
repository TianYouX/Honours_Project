package com.e_cclesia;

import android.os.Parcel;
import android.os.Parcelable;

public class ElectionModel implements Parcelable {
    String eaName;
    String electionName;
    int cardImage;
    String [] candidates;
    int [] numOfVotes;

    public ElectionModel(String eaName, String electionName, int cardImage, String[] candidates, int[] numOfVotes) {
        this.eaName = eaName;
        this.electionName = electionName;
        this.cardImage = cardImage;
        this.candidates = candidates;
        this.numOfVotes = numOfVotes;
    }

    protected ElectionModel(Parcel in) {
        eaName = in.readString();
        electionName = in.readString();
        cardImage = in.readInt();
        candidates = in.createStringArray();
        numOfVotes = in.createIntArray();
    }

    public static final Creator<ElectionModel> CREATOR = new Creator<ElectionModel>() {
        @Override
        public ElectionModel createFromParcel(Parcel in) {
            return new ElectionModel(in);
        }

        @Override
        public ElectionModel[] newArray(int size) {
            return new ElectionModel[size];
        }
    };

    public String getEaName() {
        return eaName;
    }

    public String getElectionName() {
        return electionName;
    }

    public int getCardImage() {
        return cardImage;
    }

    public String[] getCandidates() {
        return candidates;
    }

    public int[] getNumOfVotes() {
        return numOfVotes;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(eaName);
        dest.writeString(electionName);
        dest.writeInt(cardImage);
        dest.writeStringArray(candidates);
        dest.writeIntArray(numOfVotes);
    }
}
