package com.e_cclesia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.zxing.Result;

import java.util.ArrayList;

public class QRCodeScannerActivity extends AppCompatActivity {

    private ImageView ivLefticon;
    private TextView tvToolbartitle;
    private CodeScanner svCodeScanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_r_code_scanner);

        ivLefticon = findViewById(R.id.iv_lefticon);
        tvToolbartitle = findViewById(R.id.tv_toolbartitle);

        // set up the toolbar
        ivLefticon.setImageResource(R.drawable.ic_baseline_arrow_back_24);
        tvToolbartitle.setText("Scanner");
        ivLefticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        CodeScannerView scannerView = findViewById(R.id.sv_scanner);
        svCodeScanner = new CodeScanner(this, scannerView);
        svCodeScanner.startPreview();

        // Callbacks
        svCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull Result result) {

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // hard coding
                        // When scan the QR code of EA
                        if(result.getText().equals("ea")){
                            AlertDialog.Builder builder = new AlertDialog.Builder(QRCodeScannerActivity.this);
                            builder.setTitle("Registration");
                            builder.setMessage("Do you want to confirm your registration to the " + "University of Edinburgh" + "? By selecting CONFIRM your registration will succeed and you will be returned to the home page.");
                            builder.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            });
                            builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    svCodeScanner.startPreview();
                                }
                            });
                            builder.show();
                        }
                        // When scan the QR code of election
                        if(result.getText().equals("election")){
                            AlertDialog.Builder builder = new AlertDialog.Builder(QRCodeScannerActivity.this);
                            builder.setTitle("Registration");
                            builder.setMessage("Do you want to join the " + "Presidential Election" + "? By selecting CONFIRM your participantion will succeed and this election will appear in the home page.");
                            builder.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    ArrayList<ElectionModel> electionModels = new ArrayList<>();
                                    String[] eaNames = {"University of Edinburgh"};
                                    String[] electionNames = {"Presidential Election"};
                                    int [] eaImages = {R.drawable.ic_baseline_how_to_vote_24};
                                    String [] [] candidatesLists = {{"Stephen Curry", "LeBron James", "Kevin Durant"}};
                                    int [] [] numOfVotesLists = {{400,250,300}};
                                    for (int i=0; i<eaNames.length; i++){
                                        electionModels.add(new ElectionModel(eaNames[i], electionNames[i], eaImages[i], candidatesLists[i], numOfVotesLists[i]));
                                    }
                                    Intent intent = new Intent(QRCodeScannerActivity.this, MainActivity.class);
                                    intent.putExtra("ELECTION_MODEL", electionModels.get(0));
                                    startActivity(intent);
                                }
                            });
                            builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    svCodeScanner.startPreview();
                                }
                            });
                            builder.show();
                        }


                    }
                });
            }
        });


    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        svCodeScanner.startPreview();
//    }

    @Override
    protected void onPause() {
        svCodeScanner.releaseResources();
        super.onPause();
    }

}