package com.e_cclesia;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;

public class ElectionInformationService {

    String eaName;
    ElectionModel electionInformation;

    // Scan the QR code for registering with an election authority
    public interface EaInformationResponseListener{
        void onError(String message);
        void onResponse(String eaName);
    }

    public void getEaInformation(String url, EaInformationResponseListener eaInformationResponseListener){
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                eaName = "";
                try {
                    eaName = response.getString("ea_name");
                } catch (JSONException e){
                    e.printStackTrace();
                }
                eaInformationResponseListener.onResponse(eaName);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                eaInformationResponseListener.onError("Something Wrong!");
            }
        });
    }

    // Scan the QR code for joining an election
    public interface ElectionInformationResponseListener{
        void onError(String message);
        void onResponse(ElectionModel electionInformation);
    }

    public void getElectionInformation(String url, ElectionInformationResponseListener electionInformationResponseListener){
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                electionInformation = new ElectionModel("", "", R.drawable.ic_baseline_how_to_vote_24, new String[]{}, new int[]{});
                try {
                    String eaName = response.getString("ea_name");
                    String electionName = response.getString("election_name");
                    String cardImage = response.getString("card_image");
                    String [] candidates = response.getString("candidates").split(",");

                    electionInformation = new ElectionModel(eaName, electionName, Integer. parseInt(cardImage), candidates, new int[]{});
                } catch (JSONException e){
                    e.printStackTrace();
                }
                electionInformationResponseListener.onResponse(electionInformation);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                electionInformationResponseListener.onError("Something Wrong!");
            }
        });
    }

    // When the result release date comes
    public interface ResultResponseListener{
        void onError(String message);
        void onResponse(ElectionModel result);
    }

    public void getResult(String url, ResultResponseListener resultResponseListener){
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                electionInformation = new ElectionModel("", "", R.drawable.ic_baseline_how_to_vote_24, new String[]{}, new int[]{});
                try {
                    String eaName = response.getString("ea_name");
                    String electionName = response.getString("election_name");
                    String cardImage = response.getString("card_image");
                    String [] candidates = response.getString("candidates").split(",");
                    String [] numOfVotesStrings = response.getString("num_of_votes").split(",");
                    int [] numOfVotes = new int[numOfVotesStrings.length];
                    for (int i=0; i < numOfVotesStrings.length; i++){
                        numOfVotes [i] = Integer.parseInt(numOfVotesStrings [i]);
                    }

                    electionInformation = new ElectionModel(eaName, electionName, Integer. parseInt(cardImage), candidates, numOfVotes);
                } catch (JSONException e){
                    e.printStackTrace();
                }
                resultResponseListener.onResponse(electionInformation);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                resultResponseListener.onError("Something Wrong!");
            }
        });
    }

}
