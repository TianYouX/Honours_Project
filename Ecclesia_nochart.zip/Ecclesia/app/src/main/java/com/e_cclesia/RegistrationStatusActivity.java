package com.e_cclesia;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class RegistrationStatusActivity extends AppCompatActivity {

    private ImageButton ibtnElectiondetails_status;
    private ImageButton ibtnPublickey_status;
    private ImageButton ibtnPrivatekey_status;
    private TextView tvPublickeycontent_status;
    private Button btnClicktoview_status;
    private TextView tvPrivatekeycontent_status;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_status);

        ibtnElectiondetails_status = findViewById(R.id.ibtn_popup_electiondetails_status);
        ibtnPublickey_status = findViewById(R.id.ibtn_popup_publickey_status);
        ibtnPrivatekey_status = findViewById(R.id.ibtn_popup_privatekey_status);
        tvPublickeycontent_status = findViewById(R.id.tv_publickey_content_status);
        btnClicktoview_status = findViewById(R.id.btn_clicktoview_status);
        tvPrivatekeycontent_status = findViewById(R.id.tv_privatekey_content_status);

        ibtnElectiondetails_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ibtnPublickey_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ibtnPrivatekey_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnClicktoview_status.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    tvPrivatekeycontent_status.setVisibility(View.VISIBLE);
                    btnClicktoview_status.setVisibility(View.INVISIBLE);
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    tvPrivatekeycontent_status.setVisibility(View.INVISIBLE);
                    btnClicktoview_status.setVisibility(View.VISIBLE);
                    return true;
                }
                return false;
            }
        });

    }
}