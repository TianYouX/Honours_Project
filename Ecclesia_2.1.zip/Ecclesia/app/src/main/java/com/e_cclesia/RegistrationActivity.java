package com.e_cclesia;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {

    private TextView tvTitle;
    private ImageButton ibtnElectiondetails;
    private Dialog dDialog;
    private ImageButton ibtnPublickey;
    private ImageButton ibtnPrivatekey;
    private TextView tvPublickeycontent;
    private Button btnClicktoview;
    private TextView tvPrivatekeycontent;
    private TextView tvSavehint;
    private Button btnSave;
    private TextView tvFinishhint;
    private Button btnFinish;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        tvTitle = findViewById(R.id.tv_title);
        ibtnElectiondetails = findViewById(R.id.ibtn_popup_electiondetails);
        ibtnPublickey = findViewById(R.id.ibtn_popup_publickey);
        ibtnPrivatekey = findViewById(R.id.ibtn_popup_privatekey);
        tvPublickeycontent = findViewById(R.id.tv_publickey_content);
        btnClicktoview = findViewById(R.id.btn_clicktoview);
        tvPrivatekeycontent = findViewById(R.id.tv_privatekey_content);
        tvSavehint = findViewById(R.id.tv_savehint);
        btnSave = findViewById(R.id.btn_save);
        tvFinishhint = findViewById(R.id.tv_finishhint);
        btnFinish = findViewById(R.id.btn_finish);

        dDialog = new Dialog(this);
        ibtnElectiondetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dDialog.setContentView(R.layout.popup_electiondetails);
                dDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dDialog.show();
            }
        });

        ibtnPublickey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ibtnPrivatekey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnClicktoview.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    tvPrivatekeycontent.setVisibility(View.VISIBLE);
                    btnClicktoview.setVisibility(View.INVISIBLE);
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    tvPrivatekeycontent.setVisibility(View.INVISIBLE);
                    btnClicktoview.setVisibility(View.VISIBLE);
                    return true;
                }
                return false;
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(RegistrationActivity.this, "Information saved!", Toast.LENGTH_LONG).show();

                tvSavehint.setVisibility(View.INVISIBLE);
                btnSave.setVisibility(View.INVISIBLE);
                tvFinishhint.setVisibility(View.VISIBLE);
                btnFinish.setVisibility(View.VISIBLE);
            }
        });

        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(RegistrationActivity.this);
                builder.setTitle("Registration");
                builder.setMessage("Do you want to confirm your registration and become a voter? By selecting CONFIRM you will be successfully registered and proceed to the registration status page.");
                builder.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(RegistrationActivity.this, BallotCastingActivity.class);
                        startActivity(intent);
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();

            }
        });


    }
}