package com.e_cclesia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.baoyachi.stepview.HorizontalStepView;
import com.baoyachi.stepview.bean.StepBean;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BallotOpeningActivity extends AppCompatActivity {

    private ImageView ivLefticon;
    private TextView tvToolbartitle;
    private TextView tvTitleBallotopening;
    private ImageButton ibtnElectiondetails_ballotopening;
    private Dialog dDialog;
    private HorizontalStepView svTimelineBallotopening;
    private PieChart pcResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ballot_opening);

        ivLefticon = findViewById(R.id.iv_lefticon);
        tvToolbartitle = findViewById(R.id.tv_toolbartitle);
        tvTitleBallotopening = findViewById(R.id.tv_title_ballotopening);
        ibtnElectiondetails_ballotopening = findViewById(R.id.ibtn_popup_electiondetails_ballotopening);
        svTimelineBallotopening = findViewById(R.id.sv_timeline_ballotopening);
        pcResult = findViewById(R.id.pc_result);

        dDialog = new Dialog(this);
        ibtnElectiondetails_ballotopening.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dDialog.setContentView(R.layout.popup_electiondetails);
                dDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dDialog.show();
            }
        });

        ivLefticon.setImageResource(R.drawable.ic_baseline_arrow_back_24);
        tvToolbartitle.setText("Ballot Opening");
        ivLefticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        setupPieChart(pcResult);
        setupTimeline(svTimelineBallotopening);

    }

    private void setupPieChart(PieChart pc){

        //modify the appearance of the pie chart
        pc.getDescription().setEnabled(false);
        pc.setDragDecelerationFrictionCoef(0.9f);
        pc.setRotationAngle(0);
        pc.animateY(1400, Easing.EasingOption.EaseInOutQuad);
        pc.setEntryLabelColor(Color.parseColor("#FF000000"));

        //initialise the data
        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        Map<String, Integer> typeAmountMap = new HashMap<>();
        typeAmountMap.put("Stephen Curry",500);
        typeAmountMap.put("LeBron James",300);
        typeAmountMap.put("Kevin Durant",200);
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#ff9900"));
        colors.add(Color.parseColor("#ffcc00"));
        colors.add(Color.parseColor("#ffff00"));

        //input data into pie chart entry
        for(String type: typeAmountMap.keySet()){
            pieEntries.add(new PieEntry(typeAmountMap.get(type).floatValue(), type));
        }
        PieDataSet pieDataSet = new PieDataSet(pieEntries, "");
        pieDataSet.setValueTextSize(12f);
        pieDataSet.setColors(colors);
        PieData pieData = new PieData(pieDataSet);
        pieData.setDrawValues(true);

        //set up pie chart
        pc.setData(pieData);
        pc.invalidate();
    }

    private void setupTimeline(HorizontalStepView sv){
        List<StepBean> sources = new ArrayList<>();
//        sources.add(new StepBean("Registra\ntion Starts",1));
//        sources.add(new StepBean("Registra\ntion Ends",1));
        sources.add(new StepBean("Voting\nPeriod\nStarts",1));
        sources.add(new StepBean("Voted",1));
        sources.add(new StepBean("Voting\nPeriod\nEnds",1));
        sources.add(new StepBean("Results",1));

        sv.setStepViewTexts(sources)
                .setTextSize(12)
                .setStepsViewIndicatorCompletedLineColor(Color.parseColor("#FF9900"))
                .setStepViewComplectedTextColor(Color.parseColor("#FF000000"))
                .setStepsViewIndicatorUnCompletedLineColor(Color.parseColor("#FF000000"))
                .setStepViewUnComplectedTextColor(Color.parseColor("#FF000000"))
                .setStepsViewIndicatorDefaultIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_uncompleted))
                .setStepsViewIndicatorCompleteIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_completed));
        sv.setScrollBarSize(20);
    }
}