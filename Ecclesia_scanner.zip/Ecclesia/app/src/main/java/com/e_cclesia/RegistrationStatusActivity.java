package com.e_cclesia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.baoyachi.stepview.HorizontalStepView;
import com.baoyachi.stepview.bean.StepBean;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegistrationStatusActivity extends AppCompatActivity {

    private ImageButton ibtnElectiondetails_status;
    private ImageButton ibtnPublickey_status;
    private ImageButton ibtnPrivatekey_status;
    private TextView tvPublickeycontent_status;
    private Button btnClicktoview_status;
    private TextView tvPrivatekeycontent_status;
    private PieChart pcRegistration_status;
    private HorizontalStepView svTimeline;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_status);

        ibtnElectiondetails_status = findViewById(R.id.ibtn_popup_electiondetails_status);
        ibtnPublickey_status = findViewById(R.id.ibtn_popup_publickey_status);
        ibtnPrivatekey_status = findViewById(R.id.ibtn_popup_privatekey_status);
        tvPublickeycontent_status = findViewById(R.id.tv_publickey_content_status);
        btnClicktoview_status = findViewById(R.id.btn_clicktoview_status);
        tvPrivatekeycontent_status = findViewById(R.id.tv_privatekey_content_status);
        pcRegistration_status = findViewById(R.id.pc_registration_status);
        svTimeline = findViewById(R.id.sv_timeline);

        setupPieChart(pcRegistration_status);
        setupTimeline(svTimeline);

        ibtnElectiondetails_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ibtnPublickey_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        ibtnPrivatekey_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnClicktoview_status.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    tvPrivatekeycontent_status.setVisibility(View.VISIBLE);
                    btnClicktoview_status.setVisibility(View.INVISIBLE);
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    tvPrivatekeycontent_status.setVisibility(View.INVISIBLE);
                    btnClicktoview_status.setVisibility(View.VISIBLE);
                    return true;
                }
                return false;
            }
        });

    }

    private void setupPieChart(PieChart pc){

        //modify the appearance of the pie chart
        pc.setUsePercentValues(true);
        pc.getDescription().setEnabled(false);
        pc.setDragDecelerationFrictionCoef(0.9f);
        pc.setRotationAngle(0);
        pc.animateY(1400, Easing.EasingOption.EaseInOutQuad);
        pc.setEntryLabelColor(Color.parseColor("#FF000000"));

        //initialise the data
        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        Map<String, Integer> typeAmountMap = new HashMap<>();
        typeAmountMap.put("Registered",800);
        typeAmountMap.put("Not Registered",200);
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#ffc266"));
        colors.add(Color.parseColor("#FF9900"));

        //input data into pie chart entry
        for(String type: typeAmountMap.keySet()){
            pieEntries.add(new PieEntry(typeAmountMap.get(type).floatValue(), type));
        }
        PieDataSet pieDataSet = new PieDataSet(pieEntries, "");
        pieDataSet.setValueTextSize(12f);
        pieDataSet.setColors(colors);
        PieData pieData = new PieData(pieDataSet);
        pieData.setDrawValues(true);
        pieData.setValueFormatter(new PercentFormatter());

        //set up pie chart
        pc.setData(pieData);
        pc.invalidate();
    }

    private void setupTimeline(HorizontalStepView sv){
        List<StepBean> sources = new ArrayList<>();
        sources.add(new StepBean("Registra\ntion Starts",1));
        sources.add(new StepBean("Registra\ntion Ends",-1));
        sources.add(new StepBean("Voting\nStarts",-1));
        sources.add(new StepBean("Voting\nEnds",-1));
        sources.add(new StepBean("Results",-1));

        sv.setStepViewTexts(sources)
                .setTextSize(12)
                .setStepsViewIndicatorCompletedLineColor(Color.parseColor("#FF9900"))
                .setStepViewComplectedTextColor(Color.parseColor("#FF9900"))
                .setStepsViewIndicatorUnCompletedLineColor(Color.parseColor("#FF000000"))
                .setStepViewUnComplectedTextColor(Color.parseColor("#FF000000"))
                .setStepsViewIndicatorDefaultIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_uncompleted))
                .setStepsViewIndicatorCompleteIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_completed));
        sv.setScrollBarSize(20);

    }

}