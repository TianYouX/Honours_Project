package com.e_cclesia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.zxing.Result;

public class QRCodeScannerActivity extends AppCompatActivity {

    private CodeScanner svCodeScanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_r_code_scanner);

        CodeScannerView scannerView = findViewById(R.id.sv_scanner);
        svCodeScanner = new CodeScanner(this, scannerView);

        scannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                svCodeScanner.startPreview();
            }
        });

        // Callbacks
        svCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull Result result) {

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        Toast.makeText(QRCodeScannerActivity.this, result.getText(), Toast.LENGTH_LONG).show();

                    }
                });
            }
        });


    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        svCodeScanner.startPreview();
//    }

    @Override
    protected void onPause() {
        svCodeScanner.releaseResources();
        super.onPause();
    }

}