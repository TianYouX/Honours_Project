package com.e_cclesia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Election_RecyclerViewAdapter extends RecyclerView.Adapter<Election_RecyclerViewAdapter.MyViewHolder>{
    private final RecyclerViewInterface recyclerViewInterface;

    Context context;
    ArrayList<ElectionModel> electionModels;

    public Election_RecyclerViewAdapter(Context context, ArrayList<ElectionModel> electionModels, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.electionModels = electionModels;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public Election_RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recyclerview_row, parent, false);
        return new Election_RecyclerViewAdapter.MyViewHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull Election_RecyclerViewAdapter.MyViewHolder holder, int position) {
        holder.tvEaName.setText(electionModels.get(position).getEaName());
        holder.tvElectionName.setText(electionModels.get(position).getElectionName());
        holder.ivCardImage.setImageResource(electionModels.get(position).getCardImage());
    }

    @Override
    public int getItemCount() {
        return electionModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView ivCardImage;
        TextView tvEaName, tvElectionName;

        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
            ivCardImage = itemView.findViewById(R.id.iv_card_image);
            tvEaName = itemView.findViewById(R.id.tv_ea_name);
            tvElectionName = itemView.findViewById(R.id.tv_election_name);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                        int pos = getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(pos);
                        }
                    }
                }
            });

        }
    }

}
