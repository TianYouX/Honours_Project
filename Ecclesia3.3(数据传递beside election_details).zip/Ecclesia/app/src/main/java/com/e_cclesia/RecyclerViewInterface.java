package com.e_cclesia;

interface RecyclerViewInterface {
    void onItemClick(int position);
}
