package com.e_cclesia;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.baoyachi.stepview.HorizontalStepView;
import com.baoyachi.stepview.bean.StepBean;

import java.util.ArrayList;
import java.util.List;

public class BallotCastingActivity extends AppCompatActivity {

    private TextView tvTitlevoting;
    private ImageButton ibtnElectiondetails_voting;
    private Dialog dDialog;
    private HorizontalStepView svTimelinevoting;
    private AutoCompleteTextView actSelectcandidate;
    private String [] sample_candiates = {"Stephen Curry", "LeBron James", "Kevin Durant"};
    private String candiate_selected;
    private Button btnVote;
    private TextView tvSelecthint;
    private TextView tvAfterselecthint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ballot_casting);

        tvTitlevoting = findViewById(R.id.tv_title_voting);
        ibtnElectiondetails_voting = findViewById(R.id.ibtn_popup_electiondetails_voting);
        svTimelinevoting = findViewById(R.id.sv_timeline_voting);
        actSelectcandidate = findViewById(R.id.act_select_candiate);
        btnVote = findViewById(R.id.btn_vote);
        tvSelecthint = findViewById(R.id.tv_selecthint);
        tvAfterselecthint = findViewById(R.id.tv_afterselecthint);

        dDialog = new Dialog(this);
        ibtnElectiondetails_voting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dDialog.setContentView(R.layout.popup_electiondetails);
                dDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dDialog.show();
            }
        });

        setupTimeline(svTimelinevoting);

        ArrayAdapter<String> adapterItems = new ArrayAdapter<String>(this, R.layout.list_candidates, sample_candiates);
        actSelectcandidate.setAdapter(adapterItems);
        actSelectcandidate.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                in.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                btnVote.setEnabled(true);
                candiate_selected = parent.getItemAtPosition(position).toString();
            }
        });

        btnVote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(BallotCastingActivity.this);
                builder.setTitle("Ballot Casting");
                builder.setMessage("Do you comfirm that you want to vote for: " + candiate_selected + "?");
                builder.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        btnVote.setEnabled(false);
                        tvSelecthint.setVisibility(View.INVISIBLE);
                        tvAfterselecthint.setVisibility(View.VISIBLE);
                        actSelectcandidate.setDropDownHeight(0);
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });

    }

    private void setupTimeline(HorizontalStepView sv){
        List<StepBean> sources = new ArrayList<>();
        sources.add(new StepBean("Registra\ntion Starts",1));
        sources.add(new StepBean("Registra\ntion Ends",1));
        sources.add(new StepBean("Voting\nStarts",1));
        sources.add(new StepBean("Voting\nEnds",-1));
        sources.add(new StepBean("Results",-1));

        sv.setStepViewTexts(sources)
                .setTextSize(12)
                .setStepsViewIndicatorCompletedLineColor(Color.parseColor("#FF9900"))
                .setStepViewComplectedTextColor(Color.parseColor("#FF000000"))
                .setStepsViewIndicatorUnCompletedLineColor(Color.parseColor("#FF000000"))
                .setStepViewUnComplectedTextColor(Color.parseColor("#FF000000"))
                .setStepsViewIndicatorDefaultIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_uncompleted))
                .setStepsViewIndicatorCompleteIcon(ContextCompat.getDrawable(this,R.drawable.timeline_icon_completed));
        sv.setScrollBarSize(20);
    }

}