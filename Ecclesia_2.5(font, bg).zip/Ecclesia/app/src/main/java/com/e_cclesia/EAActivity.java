package com.e_cclesia;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class EAActivity extends AppCompatActivity {

    private ImageView ivLefticon;
    private TextView tvToolbartitle;
    private Dialog dDialog;
    private ImageButton ibtnScanner;
    private Button btnElectiondetails;
    private Button btnViewelection;
    private AutoCompleteTextView actElections;
    private String [] sample_elections = {"Presidential Election", "School Representatives Election"};
    private String election_selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ea);

        ivLefticon = findViewById(R.id.iv_lefticon);
        tvToolbartitle = findViewById(R.id.tv_toolbartitle);
        actElections = findViewById(R.id.act_elections);
        ibtnScanner = findViewById(R.id.ibtn_scanner);
        btnElectiondetails = findViewById(R.id.btn_electiondetails);
        btnViewelection = findViewById(R.id.btn_viewelection);

        ivLefticon.setImageResource(R.drawable.ic_baseline_arrow_back_24);
        tvToolbartitle.setText("Election Authority");
        ivLefticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ArrayAdapter<String> adapterItems = new ArrayAdapter<String>(this, R.layout.list_candidates, sample_elections);
        actElections.setAdapter(adapterItems);
        actElections.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                in.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                btnElectiondetails.setEnabled(true);
                btnViewelection.setEnabled(true);
                election_selected = parent.getItemAtPosition(position).toString();
            }
        });

        ibtnScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EAActivity.this, QRCodeScannerActivity.class);
                startActivity(intent);
            }
        });

        dDialog = new Dialog(this);
        btnElectiondetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dDialog.setContentView(R.layout.popup_electiondetails);
                dDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dDialog.show();
            }
        });

        btnViewelection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EAActivity.this, BallotCastingActivity.class);
                startActivity(intent);
            }
        });


    }
}