package com.e_cclesia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements RecyclerViewInterface{

    private ImageView ivLefticon;
    private TextView tvToolbartitle;
    private ImageView ivRighticon;
    private RecyclerView rvRecyclerview;
    private ImageView ivPlus;
    ArrayList<ElectionModel> electionModels = new ArrayList<>();
//    String[] eaNames = {"University of Edinburgh", "Tsinghua University"};
//    String[] electionNames = {"Presidential Election", "School Representative Election"};
//    int [] eaImages = {R.drawable.ic_baseline_how_to_vote_24, R.drawable.ic_baseline_how_to_vote_24};
//    String [] [] candidatesLists = {{"Stephen Curry", "LeBron James", "Kevin Durant"},
//                                    {"Tony Stark", "Steve Rogers", "Bruce Banner", "Thor"}};
//    int [] [] numOfVotesLists = {{400,250,300},
//                                 {500, 200, 300, 450}};
    String[] eaNames = {};
    String[] electionNames = {};
    int [] eaImages = {};
    String [] [] candidatesLists = {};
    int [] [] numOfVotesLists = {};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivLefticon = findViewById(R.id.iv_lefticon);
        tvToolbartitle = findViewById(R.id.tv_toolbartitle);
        ivRighticon = findViewById(R.id.iv_righticon);
        rvRecyclerview = findViewById(R.id.rv_recyclerview);
        ivPlus = findViewById(R.id.iv_plus);

        // set up tool bar
        ivLefticon.setImageResource(R.drawable.ic_baseline_home_24);
        tvToolbartitle.setText("E-cclesia");
        ivRighticon.setImageResource(R.drawable.ic_baseline_qr_code_scanner_24);
        ivRighticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, QRCodeScannerActivity.class);
                startActivity(intent);
            }
        });

        // 假更新
        Intent intent = getIntent();
        if(intent.getParcelableExtra("ELECTION_MODEL") != null){
            electionModels.add(intent.getParcelableExtra("ELECTION_MODEL"));
        }

        // set visiability of the plus sign
        if(electionModels.size() != 0){
            ivPlus.setVisibility(View.INVISIBLE);
        }

        // set up election list
        setUpElectionModels();
        Election_RecyclerViewAdapter electionRecyclerViewAdapter = new Election_RecyclerViewAdapter(this, electionModels, this);
        rvRecyclerview.setAdapter(electionRecyclerViewAdapter);
        rvRecyclerview.setLayoutManager(new LinearLayoutManager(this ));

    }

    // set up the ElectionModels
    private void setUpElectionModels(){
        for (int i=0; i<eaNames.length; i++){
            electionModels.add(new ElectionModel(eaNames[i], electionNames[i], eaImages[i], candidatesLists[i], numOfVotesLists[i]));
        }
    }

    // on click listener for the items in the list
    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(MainActivity.this, BallotCastingActivity.class);
        intent.putExtra("ELECTION_MODEL", electionModels.get(position));
        startActivity(intent);

    }

}