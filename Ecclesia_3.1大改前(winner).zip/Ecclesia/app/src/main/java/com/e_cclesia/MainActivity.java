package com.e_cclesia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private ImageView ivLefticon;
    private TextView tvToolbartitle;
    private AutoCompleteTextView actEas;
    private String [] sample_eas = {"University of Edinburgh"};
    private String ea_selected;
    private ImageButton ibtnScanner;
    private Button btnUoe;
    private Button btnEnter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivLefticon = findViewById(R.id.iv_lefticon);
        tvToolbartitle = findViewById(R.id.tv_toolbartitle);
        actEas = findViewById(R.id.act_eas);
        ibtnScanner = findViewById(R.id.ibtn_scanner);
        btnEnter = findViewById(R.id.btn_enter);
        btnUoe = findViewById(R.id.btn_uoe);

        ivLefticon.setImageResource(R.drawable.ic_baseline_home_24);
        tvToolbartitle.setText("Home");

        ArrayAdapter<String> adapterItems = new ArrayAdapter<String>(this, R.layout.list_candidates, sample_eas);
        actEas.setAdapter(adapterItems);
        actEas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                in.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                btnEnter.setEnabled(true);
                ea_selected = parent.getItemAtPosition(position).toString();
            }
        });

        ibtnScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, QRCodeScannerActivity.class);
                startActivity(intent);
            }
        });

        btnEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EAActivity.class);
                startActivity(intent);
            }
        });

        btnUoe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegistrationActivity.class);
                startActivity(intent);
            }
        });


    }

}