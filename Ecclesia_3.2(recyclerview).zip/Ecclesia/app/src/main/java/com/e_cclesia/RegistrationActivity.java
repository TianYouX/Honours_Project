package com.e_cclesia;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {

    private ImageView ivLefticon;
    private TextView tvToolbartitle;
    private TextView tvEa;
    private TextView tvPublickeycontent;
    private Button btnClicktoview;
    private TextView tvPrivatekeycontent;
    private TextView tvSavehint;
    private Button btnSave;
    private TextView tvFinishhint;
    private Button btnFinish;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        ivLefticon = findViewById(R.id.iv_lefticon);
        tvToolbartitle = findViewById(R.id.tv_toolbartitle);
        tvEa = findViewById(R.id.tv_ea);
        tvPublickeycontent = findViewById(R.id.tv_publickey_content);
        btnClicktoview = findViewById(R.id.btn_clicktoview);
        tvPrivatekeycontent = findViewById(R.id.tv_privatekey_content);
        tvSavehint = findViewById(R.id.tv_savehint);
        btnSave = findViewById(R.id.btn_save);
        tvFinishhint = findViewById(R.id.tv_finishhint);
        btnFinish = findViewById(R.id.btn_finish);

        ivLefticon.setImageResource(R.drawable.ic_baseline_arrow_back_24);
        tvToolbartitle.setText("Registration");
        ivLefticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnClicktoview.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    tvPrivatekeycontent.setVisibility(View.VISIBLE);
                    btnClicktoview.setVisibility(View.INVISIBLE);
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    tvPrivatekeycontent.setVisibility(View.INVISIBLE);
                    btnClicktoview.setVisibility(View.VISIBLE);
                    return true;
                }
                return false;
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(RegistrationActivity.this, "Information saved!", Toast.LENGTH_LONG).show();

                tvSavehint.setVisibility(View.INVISIBLE);
                btnSave.setVisibility(View.INVISIBLE);
                tvFinishhint.setVisibility(View.VISIBLE);
                btnFinish.setVisibility(View.VISIBLE);
            }
        });

        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(RegistrationActivity.this);
                builder.setTitle("Registration");
                builder.setMessage("Do you want to confirm your registration to the " + tvEa.getText() + "? By selecting CONFIRM your registration will succeed and you will be returned to the home page.");
                builder.setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();

            }
        });


    }
}