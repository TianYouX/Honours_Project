package com.e_cclesia;

public class ElectionModel {
    String eaName;
    String electionName;
    int cardImage;


    public ElectionModel(String eaName, String electionName, int cardImage) {
        this.eaName = eaName;
        this.electionName = electionName;
        this.cardImage = cardImage;
    }

    public String getEaName() {
        return eaName;
    }

    public String getElectionName() {
        return electionName;
    }

    public int getCardImage() {
        return cardImage;
    }
}
